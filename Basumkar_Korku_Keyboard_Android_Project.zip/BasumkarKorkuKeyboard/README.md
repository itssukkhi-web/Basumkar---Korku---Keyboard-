# Basumkar Korku Keyboard v1.0

This is an Android InputMethodService project for the Basumkar Korku script.

- 13 vowels
- 40 consonant entries
- 9 vowel-sign keys are planned for the next layout pass
- क्ष, त्र, ज्ञ, श्र are treated as independent characters and mapped to PUA E100-E103
- The supplied BasumkarKorku.ttf is bundled as an asset for keyboard key labels.

Important: this source project needs Android Studio/Gradle with Android SDK to build an APK. It is not itself an APK.
