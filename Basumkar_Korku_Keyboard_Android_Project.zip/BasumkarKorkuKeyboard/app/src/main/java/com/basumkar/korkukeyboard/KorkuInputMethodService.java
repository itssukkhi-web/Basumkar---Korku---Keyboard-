package com.basumkar.korkukeyboard;

import android.graphics.Typeface;
import android.inputmethodservice.InputMethodService;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import java.util.*;

public class KorkuInputMethodService extends InputMethodService {
    private LinearLayout root;
    private Typeface korku;
    private final String[][] rows = {
        {"अ","आ","इ","ई","उ","ऊ","ऋ","ए","ऐ","ओ","औ","अं","अः"},
        {"क","ख","ग","घ","ङ","च","छ","ज","झ","ञ"},
        {"ट","ठ","ड","ढ","ण","त","थ","द","ध","न"},
        {"प","फ","ब","भ","म","य","र","ल","व","श"},
        {"ष","स","ह","ड़","ढ़","ळ","क्ष","त्र","ज्ञ","श्र"}
    };
    private final String[] pua = {"\uE100","\uE101","\uE102","\uE103"};
    private final String[] vowelSigns = {"ा","ि","ी","ु","ू","े","ै","ो","ौ"};

    @Override public View onCreateInputView() {
        korku = Typeface.createFromAsset(getAssets(), "fonts/BasumkarKorku.ttf");
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(4,4,4,4); root.setBackgroundColor(Color.WHITE);
        addRow(rows[0]); addRow(rows[1]); addRow(rows[2]); addRow(rows[3]); addRow(rows[4]);
        LinearLayout bottom = new LinearLayout(this); bottom.setOrientation(LinearLayout.HORIZONTAL);
        addButton(bottom,"←",v -> getCurrentInputConnection().deleteSurroundingText(1,0));
        addButton(bottom,"␠",v -> commit(" ")); addButton(bottom,".",v -> commit("।")); addButton(bottom,"↵",v -> sendKeyEvent(new android.view.KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_ENTER)));
        root.addView(bottom,new LinearLayout.LayoutParams(-1,0,1));
        return root;
    }
    private void addRow(String[] chars){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); for(String c:chars) addButton(r,c,v -> commit(mapped(c))); root.addView(r,new LinearLayout.LayoutParams(-1,0,1)); }
    private void addButton(LinearLayout row,String text,View.OnClickListener l){ Button b=new Button(this); b.setText(text); b.setTextSize(18); b.setTypeface(korku); b.setAllCaps(false); b.setOnClickListener(l); row.addView(b,new LinearLayout.LayoutParams(0,-1,1)); }
    private String mapped(String s){ if(s.equals("क्ष"))return pua[0]; if(s.equals("त्र"))return pua[1]; if(s.equals("ज्ञ"))return pua[2]; if(s.equals("श्र"))return pua[3]; return s; }
    private void commit(String s){ if(getCurrentInputConnection()!=null) getCurrentInputConnection().commitText(s,1); }
}
